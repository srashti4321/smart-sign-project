#include <Arduino.h>
#include <BluetoothSerial.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>

BluetoothSerial SerialBT;
Adafruit_MPU6050 mpu;

// PIN MAPPING: 0=Thumb, 1=Index, 2=Middle, 3=Ring, 4=Pinky
const int pins[] = {36, 39, 34, 35, 32}; 

// Gyro Baselines
float stableX = 0, stableY = 0;

void sendSign(String text) {
    SerialBT.println(text);
    Serial.print(">>> SIGN DETECTED: ");
    Serial.println(text);
    delay(2500); 
}

void setup() {
    Serial.begin(115200);
    SerialBT.begin("SignAloud_ESP32_Pro"); 
    
    // Initialize MPU6050
    if (!mpu.begin()) {
        Serial.println("MPU6050 not found!");
    }

    Serial.println("KEEP HAND STABLE FOR CALIBRATION...");
    delay(3000); // Give you time to put hand in neutral position

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    
    // Capture the "Stable" reading
    stableX = a.acceleration.x;
    stableY = a.acceleration.y;
    
    Serial.println("SIGNALOUD SYSTEM ACTIVE & CALIBRATED");
}

void loop() {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    // Calculate how much the hand has moved/tilted from stable
    float moveDelta = abs(a.acceleration.x - stableX) + abs(a.acceleration.y - stableY);

    int val[5];
    bool open[5];

    // 1. CAPTURE HALL SENSOR SNAPSHOT
    for(int i = 0; i < 5; i++) {
        val[i] = analogRead(pins[i]);
        if (i == 1 || i == 2) { 
            open[i] = (abs(val[i] - 1900) > 600); 
        } else { 
            open[i] = (val[i] > 3000 || val[i] < 500);
        }
    }

    // 2. PATTERN MATCHING (SignAloud Heuristics)
    
    // HELLO: All main fingers open + Hand likely tilted or moving
    if (open[1] && open[2] && open[4]) {
        sendSign("HELLO");
    }
    // VICTORY: Index and Middle open, others closed + Hand relatively stable
    else if (open[1] && open[2] && !open[4] && moveDelta < 1.5) {
        sendSign("VICTORY");
    }
    // THE ONE: Only Index open, others closed
    else if (open[1] && !open[2] && !open[0] && !open[4]) {
        sendSign("THE ONE");
    }
    
    

    delay(150); 
}